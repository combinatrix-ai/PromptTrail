import logging
from abc import abstractmethod
from typing import Any, Callable, Optional, TypeAlias

logger = logging.getLogger(__name__)

TemplateId: TypeAlias = str

from src.featherchain.flow.core import FlowState


class FeatherChainHook(object):
    @abstractmethod
    def hook(self, flow_state: FlowState) -> Any:
        raise NotImplementedError("hook method is not implemented")


class TransformHook(FeatherChainHook):
    def __init__(self, function: Callable[[FlowState], FlowState]):
        self.function = function

    def hook(self, flow_state: FlowState) -> FlowState:
        return self.function(flow_state)


class BooleanHook(FeatherChainHook):
    def __init__(self, condition: Callable[[FlowState], bool]):
        self.condition = condition

    def hook(self, flow_state: FlowState) -> bool:
        return self.condition(flow_state)


class JumpHook(FeatherChainHook):
    def __init__(self, function: Callable[[FlowState], Optional[TemplateId]]):
        self.function = function

    def hook(self, flow_state: FlowState) -> Optional[TemplateId]:
        raise NotImplementedError("hook method is not implemented")


# TODO: Ask and Generate should be treated differently from other hooks
class AskUserHook(TransformHook):
    def __init__(
        self,
        key: str,
        description: Optional[str] = None,
        default: Optional[str] = None,
    ):
        self.key = key

    def hook(self, flow_state: FlowState) -> FlowState:
        message = flow_state.model.send(
            flow_state.parameters, flow_state.session_history
        )
        flow_state.data[self.key] = message.content
        return flow_state


class GenerateChatHook(TransformHook):
    def __init__(
        self,
        key: str,
    ):
        self.key = key

    def hook(self, flow_state: FlowState) -> FlowState:
        message = flow_state.model.send(
            flow_state.parameters, flow_state.session_history
        )
        flow_state.data[self.key] = message.content
        return flow_state
