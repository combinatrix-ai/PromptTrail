import logging
from typing import Any, Dict, List, Optional, Sequence, TypeAlias

from src.featherchain.core import Message, Model, Parameters, Session

logger = logging.getLogger(__name__)

TemplateId: TypeAlias = str

from src.featherchain.flow.core import FlowState
from src.featherchain.flow.templates import Template


class StatefulMessage(Message):
    data: Dict[str, Any] = {}
    template_id: Optional[str] = None


class StatefulSession(Session):
    data: Dict[str, Any] = {}
    messages: List[StatefulMessage] = []


class FlowState(object):
    def __init__(
        self,
        model: Model,
        parameters: Parameters,
        data: Dict[str, Any] = {},
        session_history: StatefulSession = StatefulSession(),
        jump: Optional[TemplateId | Template] = None,
    ):
        self.data = data
        self.model = model
        self.parameters = parameters
        self.session_history = session_history
        self.current_template: Optional[Template] = None
        self.jump: TemplateId | Template | None = jump

    def get_last_message(self) -> StatefulMessage:
        if len(self.session_history.messages) == 0:
            raise IndexError("Session has no message.")
        return self.session_history.messages[-1]

    def get_current_data(self) -> Dict[str, Any]:
        return self.data

    def get_jump(self) -> TemplateId | Template | None:
        return self.jump

    def set_jump(self, jump: TemplateId | Template | None) -> None:
        self.jump = jump

    def get_current_template(self) -> Template:
        if self.current_template is None:
            raise Exception("Current template is not set.")
        return self.current_template


class FlowRunner(object):
    def __init__(
        self,
        model: Model,
        parameters: Parameters,
        templates: Sequence[Template],
        flow_state: Optional[FlowState] = None,
    ):
        # In future it must handle models, manage task runner, and control simultaneous flow. So template itself cannot be sufficient.
        self.model = model
        self.parameters = parameters
        self.templates = templates
        self.flow_state = flow_state
        self.template_dict: Dict[TemplateId, Template] = {}
        for template in self.templates:
            if template.id in self.template_dict:
                raise ValueError(f"Template id {template.id} is duplicated.")
            self.template_dict[template.id] = template

    def run(
        self,
        start_template: Optional[Template | TemplateId] = None,
        flow_state: Optional[FlowState] = None,
    ) -> FlowState:
        if flow_state is None:
            flow_state = FlowState(
                model=self.model,
                parameters=self.parameters,
                data={},
                session_history=StatefulSession(),
                jump=None,
            )
        if start_template is not None:
            if isinstance(start_template, str):
                start_template = self._search_template(start_template)
            elif not isinstance(start_template, Template):  # type: ignore
                raise TypeError("start_template must be Template or TemplateId.")

        template = start_template if start_template is not None else self.templates[0]
        while 1:
            flow_state = template.render(flow_state)
            if flow_state.jump is not None:
                if not isinstance(flow_state.jump, Template):
                    template = self._search_template(flow_state.jump)
                flow_state.jump = None
            else:
                logger.info(f"No jump is set. Flow is finished.")
                break
        return flow_state

    def _search_template(self, template_id: TemplateId) -> Template:
        if template_id not in self.template_dict:
            raise ValueError(f"Template id {template_id} is not found.")
        return self.template_dict[template_id]
