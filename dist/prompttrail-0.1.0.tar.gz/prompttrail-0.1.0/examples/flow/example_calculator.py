import os

from featherchain.providers.openai import (
    OpenAIChatCompletionModel,
    OpenAIModelConfiguration,
    OpenAIModelParameters,
)

from featherchain.flow.templates import (
    LinearTemplate,
    MessageTemplate,
    LoopTemplate,
)
from featherchain.flow.hooks import (
    AskUserHook,
    GenerateChatHook,
    ExtractSegmentHook,
    EvaluatePythonCodeHook,
    BooleanHook,
)
from featherchain.flow.core import FlowRunner

flow_template = LinearTemplate(
    [
        MessageTemplate(
            role="system",
            content="""
            You're a helpful assistant to solve Fermi Problem.
            Answer the equation to estimate the answer to the user's query.

            For example, if user ask you `How many cats in Japan?`, your answer should look like below.
            Note that you must return python expression to for user to calculate it using Python.
            
            Thoughts:
            - I don't have no knowledge about the number of cats in Japan. However, I can estimate it using available knowledge.
            - As of 2019, about 67% of households in the United States owned either dogs or cats, with about 49% of households owning cats (source: American Pet Products Association).
            - Assuming the trend in Japan follows a similar pattern to the U.S., we can look at the total number of households in Japan, and estimate that about 49% of them own a cat.
            - The total number of households in Japan is about 53 million (source: Japan's Ministry of Internal Affairs and Communications, 2020).
            - We also need to consider the average number of cats per household.
            - In the U.S, the average number of cats per household is 2.1 (source: American Veterinary Medical Association).
            - If we apply this to Japan, we can estimate the total number of cats in Japan.
            - Now I can estimate the answer.

            Equation to be calculated:
            - Total Number of Cats in Japan = Total Number of Households in Japan * Rate of Households owning cats  * Average Number of Cats Per Household
            
            Calculation:
            ```python
            5300000 * 0.49 * 2.1
            ```
            """,
        ),
        LoopTemplate(
            [
                MessageTemplate(
                    role="user",
                    before_transform=[
                        AskUserHook(
                            key="prompt",
                            description="Input:",
                            default="How many elephants in Japan?",
                        )
                    ],
                    content="""
                    {% prompt %}
                    """,
                ),
                MessageTemplate(
                    role="assistant",
                    before_transform=[GenerateChatHook(key="generated_text")],
                    content="""
                    {% generated_text %}
                    """,
                    after_transform=[
                        ExtractSegmentHook(key="python_segment", lang="python"),
                        EvaluatePythonCodeHook(key="answer"),
                    ],
                ),
                MessageTemplate(
                    role="assistant",
                    content="""
                    The answer is {% answer %}. Satisfied?
                    """,
                ),
                MessageTemplate(
                    role="user",
                    before_transform=[
                        AskUserHook(
                            key="feedback", description="Input:", default="Let's retry."
                        )
                    ],
                    content="""
                    {% feedback %}
                    """,
                ),
                MessageTemplate(
                    role="assistant",
                    content="""
                    The user has stated their feedback. If you think the user is satisified, you must answer `END`. Otherwise, you must answer `RETRY`.
                    """,
                ),
                check_end := MessageTemplate(
                    role="assistant",
                    before_transform=[GenerateChatHook(key="generated_text")],
                    content="""
                    {% generated_text %}
                    """,
                ),
            ],
            exit_condition=BooleanHook(
                condition=lambda flow_state: (
                    flow_state.get_current_template().id == check_end.id
                    and "END" in flow_state.get_last_message().content
                )
            ),
        ),
    ],
)

runner = FlowRunner(
    model=OpenAIChatCompletionModel(
        configuration=OpenAIModelConfiguration(
            api_key=os.environ.get("OPENAI_API_KEY", "")
        )
    ),
    parameters=OpenAIModelParameters(model_name="gpt-3.5-turbo"),
    templates=[flow_template],
)

runner.run()
